@echo off
REM ============================================================
REM  Bantu Uninstaller v1.2.2
REM ============================================================
setlocal EnableDelayedExpansion
title Bantu Uninstaller

echo.
echo   Uninstalling Bantu v1.2.2...
echo.

REM --- Remove PATH entry ---
for /f "tokens=2*" %%A in ('reg query "HKCU\Environment" /v PATH 2^>nul') do set "USERPATH=%%B"
if defined USERPATH (
    set "NEWPATH=!USERPATH:;%LOCALAPPDATA%\Bantu\bin=!"
    set "NEWPATH=!NEWPATH:%LOCALAPPDATA%\Bantu\bin;=!"
    if "!NEWPATH!"=="!USERPATH!" (
        REM PATH entry not present, skip
    ) else (
        setx PATH "!NEWPATH!" >nul 2>&1
    )
)

REM --- Remove file associations ---
reg delete "HKCU\Software\Classes\.b" /f >nul 2>&1
reg delete "HKCU\Software\Classes\Bantu.Source" /f >nul 2>&1

REM --- Remove shortcuts ---
del "%USERPROFILE%\Desktop\Bantu REPL.lnk" >nul 2>&1
rmdir /S /Q "%APPDATA%\Microsoft\Windows\Start Menu\Programs\Bantu" >nul 2>&1

REM --- Remove installation folder ---
rmdir /S /Q "%LOCALAPPDATA%\Bantu" >nul 2>&1

echo   Bantu has been uninstalled.
echo.
pause
endlocal
