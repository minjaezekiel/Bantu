// fib.b — recursive Fibonacci
def fib($n) {
    if ($n < 2) { return $n; }
    return fib($n - 1) + fib($n - 2);
}

each ($i in range(0, 15)) {
    print("fib(" + $i + ") = " + fib($i));
}
