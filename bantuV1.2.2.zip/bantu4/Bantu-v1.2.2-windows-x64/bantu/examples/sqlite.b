// sqlite.b — SQLite is always available (no extra deps)
sua.sqlite.connect(":memory:");
sua.sqlite.exec("CREATE TABLE users (id INTEGER PRIMARY KEY, name TEXT)");
sua.sqlite.exec("INSERT INTO users (name) VALUES ('Alice')");
sua.sqlite.exec("INSERT INTO users (name) VALUES ('Bob')");

$rows = sua.sqlite.query("SELECT * FROM users");
each ($row in $rows) {
    print("id=" + $row["id"] + " name=" + $row["name"]);
}
