// hello.b — your first Bantu program
print("Hello, Bantu!");

def greet($name) {
    print("Habari, " + $name + "!");
}

greet("Assey");

$nums = [1, 2, 3, 4, 5];
$total = 0;
each ($n in $nums) {
    $total = $total + $n;
}
print("Sum = " + $total);
