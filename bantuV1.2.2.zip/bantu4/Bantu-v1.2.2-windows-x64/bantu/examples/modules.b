// modules.b — uses include to import math_helpers.b
include "./math_helpers.b";

print("square(5) = " + square(5));
print("cube(3) = " + cube(3));
print("factorial(6) = " + factorial(6));
