// math_helpers.b — imported via the include keyword
def square($x) { return $x * $x; }
def cube($x)   { return $x * $x * $x; }
def factorial($n) {
    if ($n < 2) { return 1; }
    return $n * factorial($n - 1);
}
