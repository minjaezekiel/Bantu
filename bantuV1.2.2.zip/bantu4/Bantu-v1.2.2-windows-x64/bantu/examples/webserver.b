// webserver.b — minimal Sua web server
sua.server.get("/", def($req, $res) {
    $res.html("<h1>Hello from Bantu!</h1>");
});

sua.server.get("/api/health", def($req, $res) {
    $res.json({ "ok": true, "version": "1.2.2" });
});

print("Server starting on http://localhost:3000");
sua.server.listen(3000);
