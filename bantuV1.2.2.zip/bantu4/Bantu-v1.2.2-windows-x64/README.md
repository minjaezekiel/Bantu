# Bantu v1.2.2 — Windows Installer

A **single pre-built `bantu.exe`** plus everything you need to start
coding in Bantu on Windows in under a minute. No compilation, no
CMake, no Visual Studio — just unzip, double-click `install.bat`,
and you're done.

## What's Inside

| File | Purpose |
|---|---|
| `install.bat` | One-click installer — copies `bantu.exe` to `%LOCALAPPDATA%\Bantu\bin\`, adds it to PATH, registers `.b` file type, installs the VSCode extension, creates shortcuts |
| `uninstall.bat` | Removes everything `install.bat` did |
| `try-bantu.bat` | Opens a fresh Command Prompt with Bantu ready to go |
| `bantu\bin\bantu.exe` | Pre-built 64-bit Windows binary (statically linked, no DLLs needed) |
| `bantu\examples\` | Sample `.b` programs you can run right away |
| `bantu\bantu-vscode-1.2.2.vsix` | VSCode extension with syntax highlighting, autocomplete, blue-B icon, F5 run |
| `bantu\docs\Bantu-Programming-Language-v1.2.2.pdf` | 30-page official language guide |
| `README.md` | This file |

## Quick Start (3 steps)

1. **Unzip** this folder anywhere (e.g. `Downloads\Bantu-v1.2.2-windows-x64`)
2. **Double-click `install.bat`** — that's it. The installer:
   - Copies `bantu.exe` to `%LOCALAPPDATA%\Bantu\bin\`
   - Adds that folder to your user `PATH`
   - Registers `.b` as a Bantu source file (double-clicking a `.b` runs it)
   - **Auto-installs the VSCode extension** if VSCode is detected
   - Creates a desktop shortcut and Start Menu entry
3. **Open a NEW Command Prompt** (so PATH reloads) and verify:

```bat
bantu --version
:: → Bantu v1.2.2
```

## Create Your First Project

From any folder:
```bat
cd %USERPROFILE%\Code
bantu init myproject
cd myproject
bantu run
:: → Hello, Bantu!
```

Or scaffold a Sua web app:
```bat
bantu init --web mywebapp
cd mywebapp
bantu run server.b
:: → Sua server listening on http://localhost:3000
```

## Use Bantu in VSCode

After `install.bat` runs (and if VSCode is installed), you get:

- **Syntax highlighting** for `.b` files
- **Blue-B file icon** in the explorer
- **Autocomplete** for keywords, types, and `sua.*` APIs
- **Hover hints** and **Go-to-Symbol** (`Ctrl+Shift+O`)
- **F5** runs the current `.b` file

If VSCode isn't installed yet, install it from <https://code.visualstudio.com/>,
then run `install.bat` again (or install the VSIX manually via
**Ctrl+Shift+P → Extensions: Install from VSIX → bantu-vscode-1.2.2.vsix**).

## Build a Windows Installer for Your Own App

Once you've written a Bantu app (e.g. `main.b`), you can ship it as a
single `.exe` installer:

```bat
bantu build-windows --name "MyApp" --version "1.0.0"
:: → dist\MyApp-Setup-1.0.0.exe
```

This requires [NSIS](https://nsis.sourceforge.io/Download) on PATH
(one-time install).

## Uninstall

Either:
- Run `uninstall.bat` from this folder, **or**
- Use **Add/Remove Programs** in Windows Settings → find "Bantu" → Uninstall

Both remove `bantu.exe`, the PATH entry, file associations, shortcuts,
and the install directory.

## Troubleshooting

| Problem | Fix |
|---|---|
| `bantu` not recognized after install | Open a **new** Command Prompt so PATH reloads |
| VSCode extension not auto-installed | Install VSCode first, then re-run `install.bat` |
| `bantu --version` shows older version | Uninstall the old version first (`%LOCALAPPDATA%\Bantu\uninstall.bat`), then re-install |
| Antivirus flags `bantu.exe` | It's a false positive — the binary is statically linked C++ with no runtime DLL deps. Add `%LOCALAPPDATA%\Bantu\bin\` to your AV exclusions if it persists. |

## System Requirements

- Windows 10 64-bit or later (Windows 11 supported)
- 5 MB free disk space
- VSCode 1.75+ (optional, for the editor extension)
