@echo off
REM ============================================================
REM  Bantu Programming Language - One-Click Installer v1.2.2
REM  Pre-built bantu.exe + auto-installs VSCode extension
REM ============================================================
setlocal EnableDelayedExpansion
title Bantu Installer v1.2.2

echo.
echo   =====================================================
echo    Bantu Programming Language - Installer v1.2.2
echo    Pre-built binary + VSCode integration
echo   =====================================================
echo.

set "INSTALLER_DIR=%~dp0"
set "BANTU_SRC=%INSTALLER_DIR%bantu"
set "BANTU_DEST=%LOCALAPPDATA%\Bantu"

REM ============================================================
REM STEP 1: Install bantu.exe
REM ============================================================
echo   [1/6] Installing bantu.exe to %BANTU_DEST%
if not exist "%BANTU_DEST%\bin" mkdir "%BANTU_DEST%\bin"
if not exist "%BANTU_DEST%\examples" mkdir "%BANTU_DEST%\examples"
if not exist "%BANTU_DEST%\docs"     mkdir "%BANTU_DEST%\docs"

copy /Y "%BANTU_SRC%\bin\bantu.exe" "%BANTU_DEST%\bin\bantu.exe" >nul 2>&1
if not exist "%BANTU_DEST%\bin\bantu.exe" (
    echo   [FAILED] Could not copy bantu.exe
    pause
    exit /b 1
)
echo         OK - bantu.exe installed

REM ============================================================
REM STEP 2: Copy examples and docs
REM ============================================================
echo   [2/6] Copying example programs and docs...
xcopy /Y /E /I "%BANTU_SRC%\examples" "%BANTU_DEST%\examples" >nul 2>&1
copy /Y "%BANTU_SRC%\docs\Bantu-Programming-Language-v1.2.2.pdf" "%BANTU_DEST%\docs\" >nul 2>&1
echo         OK

REM ============================================================
REM STEP 3: Add to PATH
REM ============================================================
echo   [3/6] Adding Bantu to your PATH...
for /f "tokens=2*" %%A in ('reg query "HKCU\Environment" /v PATH 2^>nul') do set "USERPATH=%%B"
if not defined USERPATH set "USERPATH="
echo !USERPATH! | findstr /I /C:"%BANTU_DEST%\bin" >nul
if errorlevel 1 (
    if defined USERPATH (
        setx PATH "!USERPATH!;%BANTU_DEST%\bin" >nul 2>&1
    ) else (
        setx PATH "%BANTU_DEST%\bin" >nul 2>&1
    )
    echo         OK - PATH updated
) else (
    echo         OK - PATH already configured
)

REM ============================================================
REM STEP 4: Register .b file association
REM ============================================================
echo   [4/6] Registering .b file type...
reg add "HKCU\Software\Classes\.b" /ve /d "Bantu.Source" /f >nul 2>&1
reg add "HKCU\Software\Classes\Bantu.Source" /ve /d "Bantu Source File" /f >nul 2>&1
reg add "HKCU\Software\Classes\Bantu.Source\DefaultIcon" /ve /d "%BANTU_DEST%\bin\bantu.exe,0" /f >nul 2>&1
reg add "HKCU\Software\Classes\Bantu.Source\shell\open\command" /ve /d "\"%BANTU_DEST%\bin\bantu.exe\" run \"%%1\"" /f >nul 2>&1
echo         OK

REM ============================================================
REM STEP 5: Install VSCode extension (if VSCode is installed)
REM ============================================================
echo   [5/6] Installing VSCode extension...
set "VSIX=%BANTU_SRC%\bantu-vscode-1.2.2.vsix"

set "CODE_CMD="
where code >nul 2>&1 && set "CODE_CMD=code"
if not defined CODE_CMD (
    if exist "%LOCALAPPDATA%\Programs\Microsoft VS Code\bin\code.cmd" (
        set "CODE_CMD=%LOCALAPPDATA%\Programs\Microsoft VS Code\bin\code.cmd"
    )
)
if not defined CODE_CMD (
    if exist "%ProgramFiles%\Microsoft VS Code\bin\code.cmd" (
        set "CODE_CMD=%ProgramFiles%\Microsoft VS Code\bin\code.cmd"
    )
)

if defined CODE_CMD (
    echo         Found VSCode: !CODE_CMD!
    echo         Installing bantu-vscode-1.2.2.vsix...
    "!CODE_CMD!" --install-extension "%VSIX%" --force 2>&1 | findstr /I /C:"Installing" /C:"Successfully" /C:"already" /C:"was installed"
    echo         OK - VSCode extension installed
) else (
    echo         [SKIP] VSCode not found on this machine.
    echo         You can install the extension manually later:
    echo           1. Open VSCode
    echo           2. Press Ctrl+Shift+P
    echo           3. Type "Extensions: Install from VSIX"
    echo           4. Select: %VSIX%
)

REM ============================================================
REM STEP 6: Create shortcuts
REM ============================================================
echo   [6/6] Creating shortcuts...

REM Desktop shortcut to REPL
set "SHORTCUT=%USERPROFILE%\Desktop\Bantu REPL.lnk"
> "%TEMP%\mksc.vbs" echo Set ws = CreateObject("WScript.Shell")
>> "%TEMP%\mksc.vbs" echo Set sc = ws.CreateShortcut("%SHORTCUT%")
>> "%TEMP%\mksc.vbs" echo sc.TargetPath = "%BANTU_DEST%\bin\bantu.exe"
>> "%TEMP%\mksc.vbs" echo sc.WorkingDirectory = "%USERPROFILE%"
>> "%TEMP%\mksc.vbs" echo sc.Description = "Start Bantu REPL"
>> "%TEMP%\mksc.vbs" echo sc.Save
cscript //nologo "%TEMP%\mksc.vbs" >nul 2>&1
del "%TEMP%\mksc.vbs" >nul 2>&1

REM Start Menu shortcut
set "STARTMENU=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Bantu"
if not exist "%STARTMENU%" mkdir "%STARTMENU%"
set "SHORTCUT2=%STARTMENU%\Bantu REPL.lnk"
> "%TEMP%\mksc2.vbs" echo Set ws = CreateObject("WScript.Shell")
>> "%TEMP%\mksc2.vbs" echo Set sc = ws.CreateShortcut("%SHORTCUT2%")
>> "%TEMP%\mksc2.vbs" echo sc.TargetPath = "%BANTU_DEST%\bin\bantu.exe"
>> "%TEMP%\mksc2.vbs" echo sc.WorkingDirectory = "%USERPROFILE%"
>> "%TEMP%\mksc2.vbs" echo sc.Description = "Start Bantu REPL"
>> "%TEMP%\mksc2.vbs" echo sc.Save
cscript //nologo "%TEMP%\mksc2.vbs" >nul 2>&1
del "%TEMP%\mksc2.vbs" >nul 2>&1

REM Start Menu — Uninstall shortcut
set "SHORTCUT3=%STARTMENU%\Uninstall Bantu.lnk"
> "%TEMP%\mksc3.vbs" echo Set ws = CreateObject("WScript.Shell")
>> "%TEMP%\mksc3.vbs" echo Set sc = ws.CreateShortcut("%SHORTCUT3%")
>> "%TEMP%\mksc3.vbs" echo sc.TargetPath = "%BANTU_DEST%\bin\bantu.exe"
>> "%TEMP%\mksc3.vbs" echo sc.Arguments = ""
>> "%TEMP%\mksc3.vbs" echo sc.IconLocation = "shell32.dll,131"
>> "%TEMP%\mksc3.vbs" echo sc.Save
del "%BANTU_DEST%\uninstall-link.txt" 2>nul
> "%TEMP%\mkun.vbs" echo Set ws = CreateObject("WScript.Shell")
>> "%TEMP%\mkun.vbs" echo Set sc = ws.CreateShortcut("%SHORTCUT3%")
>> "%TEMP%\mkun.vbs" echo sc.TargetPath = "%BANTU_DEST%\uninstall.bat"
>> "%TEMP%\mkun.vbs" echo sc.Save
cscript //nologo "%TEMP%\mkun.vbs" >nul 2>&1
del "%TEMP%\mkun.vbs" >nul 2>&1

REM Copy uninstall.bat into the install dir
copy /Y "%INSTALLER_DIR%uninstall.bat" "%BANTU_DEST%\uninstall.bat" >nul 2>&1

echo         OK

REM ============================================================
REM Done
REM ============================================================
echo.
echo   =====================================================
echo    INSTALLATION COMPLETE!
echo   =====================================================
echo.
echo    Bantu is installed at:
echo        %BANTU_DEST%\bin\bantu.exe
echo.
if defined CODE_CMD (
    echo    VSCode extension: INSTALLED AUTOMATICALLY
    echo    Open any .b file in VSCode and press F5 to run it.
) else (
    echo    VSCode extension: saved at %VSIX%
    echo    Install VSCode first, then run this installer again.
)
echo.
echo    HOW TO USE:
echo.
echo    1. Open a NEW Command Prompt and type:
echo              bantu --version
echo.
echo    2. Create a new Bantu project from any folder:
echo              cd %USERPROFILE%\Code
echo              bantu init myproject
echo              cd myproject
echo              bantu run
echo.
echo    3. Or in VSCode: open any .b file and press F5.
echo.
echo    4. Start the interactive REPL:
echo              bantu repl
echo.
echo    5. Build a Windows installer for your own app:
echo              bantu build-windows --name "MyApp" --version "1.0.0"
echo.
echo    NOTE: Open a NEW Command Prompt window for PATH
echo    changes to take effect.
echo.
echo   =====================================================
echo.
pause
endlocal
