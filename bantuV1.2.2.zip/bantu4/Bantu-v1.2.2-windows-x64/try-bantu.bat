@echo off
REM ============================================================
REM  Bantu Quick Test — opens a fresh Command Prompt with
REM  Bantu in PATH and runs --version + a hello world
REM ============================================================
start cmd /k "echo Welcome to Bantu v1.2.2! & echo. & bantu --version & echo. & echo Try: bantu init myproject ^&^& cd myproject ^&^& bantu run"
